/*
SQLyog Job Agent v11.42 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.15 : Database - dbaccount
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`dbaccount` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;

USE `dbaccount`;

/*Table structure for table `tblfriend` */

DROP TABLE IF EXISTS `tblfriend`;

CREATE TABLE `tblfriend` (
  `UserUID` bigint(20) NOT NULL,
  `FriendUID` bigint(20) NOT NULL,
  `FriendFacebookUID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`UserUID`,`FriendUID`),
  UNIQUE KEY `PK_Unique` (`UserUID`,`FriendUID`) USING HASH,
  KEY `PrimaryIndex` (`UserUID`,`FriendUID`),
  KEY `FriendID_Index` (`FriendUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tblfriend` */

insert  into `tblfriend` values (21104,22223,100001894965105),(21105,22223,100001894965105),(22223,21104,0),(22223,21105,0),(22223,22224,100001854056790),(22223,22225,100001384095859),(22223,22228,1839626376),(22224,22223,100001894965105),(22224,22225,100001384095859),(22224,22228,1839626376),(22225,22223,100001894965105),(22225,22224,100001854056790),(22225,22228,1839626376),(22228,22223,100001894965105),(22228,22224,100001854056790),(22228,22225,100001384095859);

/*Table structure for table `tblnotification` */

DROP TABLE IF EXISTS `tblnotification`;

CREATE TABLE `tblnotification` (
  `NotificationID` int(11) NOT NULL AUTO_INCREMENT,
  `UserUID` bigint(20) unsigned NOT NULL,
  `MessageID` smallint(5) unsigned NOT NULL,
  `MessageParam0` bigint(20) DEFAULT NULL,
  `MessageParam1` bigint(20) DEFAULT NULL,
  `MessageText` varchar(512) DEFAULT NULL,
  `IssuedTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`NotificationID`),
  UNIQUE KEY `NotificationID_UNIQUE` (`NotificationID`),
  KEY `UserID_KEY` (`UserUID`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

/*Data for the table `tblnotification` */

insert  into `tblnotification` values (1,10,3,22223,8594313445456,'케이군1','2013-09-08 19:36:46'),(35,13,3,22229,8594313445469,'신띠아','2013-09-08 22:39:31'),(11,12,3,22228,8594313445465,'충쿤','2013-09-08 22:25:40'),(10,10,3,22228,8594313445465,'충쿤','2013-09-08 22:25:38'),(12,13,3,22228,8594313445465,'충쿤','2013-09-08 22:25:40'),(57,21105,3,22223,8594313445463,'케이군1','2013-10-30 23:53:52'),(34,12,3,22229,8594313445469,'신띠아','2013-09-08 22:39:30'),(33,10,3,22229,8594313445469,'신띠아','2013-09-08 22:39:29'),(53,22223,3,22225,8594313445486,'catlatte','2013-10-21 21:01:29'),(54,22224,3,22225,8594313445486,'catlatte','2013-10-21 21:01:30'),(55,22227,3,22225,8594313445486,'catlatte','2013-10-21 21:01:30');

/*Table structure for table `tbluser` */

DROP TABLE IF EXISTS `tbluser`;

CREATE TABLE `tbluser` (
  `UserUID` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'User unique ID which is assigned by us',
  `UserName` varchar(60) DEFAULT NULL COMMENT 'User account name',
  `UserPassword` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT 'Password',
  `FBUserID` bigint(20) DEFAULT NULL COMMENT 'Facebook user ID',
  `GameNick` varchar(60) NOT NULL COMMENT 'Default nick name in game',
  `LatestLoggedIn` timestamp NULL DEFAULT NULL COMMENT 'Latest logged in time',
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `LoginToken` varchar(512) NOT NULL DEFAULT '0',
  `EMail` varchar(45) DEFAULT NULL,
  `GCMKeys` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`UserUID`),
  UNIQUE KEY `UserID_UNIQUE` (`UserUID`),
  UNIQUE KEY `UserName_UNIQUE` (`UserName`),
  UNIQUE KEY `FBUserID_UNIQUE` (`FBUserID`),
  UNIQUE KEY `Email_UNIQUE` (`EMail`)
) ENGINE=InnoDB AUTO_INCREMENT=22231 DEFAULT CHARSET=utf8 COMMENT='User account table';

/*Data for the table `tbluser` */

insert  into `tbluser` values (4279,'1','1',NULL,'1',NULL,'2013-07-06 22:01:55','0',NULL,NULL),(4282,'2','2',NULL,'2',NULL,'2013-07-06 22:05:56','0',NULL,NULL),(4297,'','',NULL,'','2013-07-06 23:27:38','2013-07-06 22:18:57','0',NULL,NULL),(21104,'Tester1','Tester1',NULL,'Tester1','2014-04-19 23:19:47','2013-07-07 00:55:49','0','test1@test.com',NULL),(21105,'Tester2','Tester2',NULL,'Tester2','2014-04-12 19:37:28','2013-07-07 00:55:57','0','test2@test.com',NULL),(21106,'Tester3','Tester3',NULL,'Tester3','2014-04-12 19:37:55','2013-07-07 00:56:04','0','test3@test.com',NULL),(21107,'Tester4','Tester4',NULL,'Tester4','2014-04-12 19:38:01','2013-07-07 00:56:10','0','test4@test.com',NULL),(21108,'Tester5','Tester5',NULL,'Tester5',NULL,'2013-07-07 00:56:16','0','test5@test.com',NULL),(21109,'Tester6','Tester6',NULL,'Tester6',NULL,'2013-07-07 00:56:23','0','test6@test.com',NULL),(21110,'Tester7','Tester7',NULL,'Tester7',NULL,'2013-07-07 00:56:30','0','test7@test.com',NULL),(21111,'Tester8','Tester8',NULL,'Tester8',NULL,'2013-07-07 00:56:36','0','test8@test.com',NULL),(21112,'Tester9','Tester9',NULL,'Tester9',NULL,'2013-07-07 00:56:42','0','test9@test.com',NULL),(21113,'Tester10','Tester10',NULL,'Tester10',NULL,'2013-07-07 00:56:50','0','test10@test.com',NULL),(21114,'Tester11','Tester11',NULL,'Tester11',NULL,'2013-07-07 00:56:56','0','test11@test.com',NULL),(21115,'Tester12','Tester12',NULL,'Tester12',NULL,'2013-07-07 00:57:01','0','test12@test.com',NULL),(21116,'Tester13','Tester13',NULL,'Tester13',NULL,'2013-07-07 00:57:06','0','test13@test.com',NULL),(21117,'Tester14','Tester14',NULL,'Tester14',NULL,'2013-07-07 00:57:11','0','test14@test.com',NULL),(21118,'Tester15','Tester15',NULL,'Tester15',NULL,'2013-07-07 00:57:20','0','test15@test.com',NULL),(21119,'Tester16','Tester16',NULL,'Tester16',NULL,'2013-07-07 00:57:26','0','test16@test.com',NULL),(21120,'Tester17','Tester17',NULL,'Tester17',NULL,'2013-07-07 00:57:36','0','test17@test.com',NULL),(21121,'Tester18','Tester18',NULL,'Tester18',NULL,'2013-07-07 00:57:42','0','test18@test.com',NULL),(21122,'Tester19','Tester19',NULL,'Tester19',NULL,'2013-07-07 00:57:52','0','test19@test.com',NULL),(21123,'Tester20','Tester20',NULL,'Tester20',NULL,'2013-07-07 00:58:00','0','test20@test.com',NULL),(22223,NULL,NULL,100001894965105,'케이군1','2014-03-09 18:19:03','2013-07-12 23:50:04','0','blue3k@gmail.com','APA91bF8Zu-n9V2ZG_admoSl3jjq0klNG065RM1a3Sgd258MesfcnZetAzG0OwwbyrK6c2NSzCIkuB1Uoh_u3cFfx-DgwNP6dvNaPB0C25eIHJk0Yvdln9rOGXXpU2iuv5B__iTOXTspOfn3FnI5ricDH8fd7ooBVw'),(22224,NULL,NULL,100001854056790,'야호','2014-02-19 22:57:58','2013-07-14 16:43:33','0','yaho0620@gmail.com','APA91bEVrTVkfZKKbkNLPGfgJTq6R3-QHBCZdHrOE6Dia6dDJ5Oh_lPMjurHOi3VKgK_n9y0OdIb53EZ852qlKgJlPGNRkv4E1oAkcyi66NhZNJZebNkdF4hyOuZYnCgp5U2YcYD5iuWThjt8gQmu_H7gtTpMrj_GQ'),(22225,NULL,NULL,100001384095859,'catlatte','2014-02-19 22:57:17','2013-07-14 16:52:53','0','jth0927@hotmail.com','APA91bG4bd33spok-qPT-MTMyRz0grToua_kQIgOE7FPB7ZsQrkxzabuRogMoHbc4TWzWnqvT1TL0aXspI66iS7OQXbMXiyqugGeTCsk0IOh9R9OXMY12SRXnmsMLklLzOVpOrwPztMEBoCIgySE_x5yEha56ZLrAQ'),(22226,NULL,NULL,1795378172,'짱군','2014-02-19 22:49:50','2013-07-14 17:01:54','0','amiesuie@naver.com','APA91bEGTeAbPDr7XDIth4N2Ws-dBSF0PuQAMw08Yt9FVFmgwxGqBSmF3aOz0Igasdfp6gb1TJsJwdzonShLu51PvfQtnR0Wm4I_oLGSWMjqxqTDUyMFkAjognX2tQcivFTbjwrI4XpExXChPFoyy9ljeyepMIfjIg'),(22227,NULL,NULL,100001831377230,'바락','2014-02-19 22:08:10','2013-07-14 17:12:02','0','barakcao@gmail.com','APA91bFipSmr-kZLBY74JeMTNKogH_UT9o6buPzuqsGAupXRpr64Z_ZNq6kpGGaw-5Cgesh4_JodjOKaZRdzDE-K-bjUXB9Mdbr_pWgpQxZzfnktlwLMcz0yB6AbZUCjWs-d2RLCB8qJqPXJZC-MsPxiVYgxEx0yGw'),(22228,NULL,NULL,1839626376,'충쿤','2014-02-22 12:48:11','2013-08-02 14:33:03','0','proib@naver.com','APA91bHAO8FMKumJaNIRvIsbkHQz9dC4nl-qvXlvk7plR5dNi3koD6KxuG5FgDnh8hZideYmiBtSMviC6R0TMliHSls8udIPFnNPXQiW4N1mRNCZ-ZwnkwZKWi3iqj7p2cj6KxXo5QUlqxfuTIcn3uqvmUjbgWQQOw'),(22229,NULL,NULL,100002036101529,'신띠아','2013-11-02 14:57:16','2013-08-02 22:19:26','0','durmi@hanmail.net','APA91bEvxmIyOCI49lhFr5bFnS1vMg3-FoX-xWTRU1m9utqZB8_8WN3X2tnlPik3GGJroA9AtHS78BqOGx4iemBUT_AxswO9BMPMd-OR5LBqifIpEyRkybBuOtgEtQE3kIm47I_Hwy2cTS5Wao6G9drgYSdpX-vHWw'),(22230,NULL,NULL,100007377433012,'Taehun Jeong','2014-02-02 16:09:48','2014-02-02 15:35:27','0','jth0927@gmail.com','APA91bELpmiuX7fmFb43dxRXoZbeLonBYZ8fSUk2PUjrPtJ_N43TCOt3hW9vga72Ab2oFOEqMmHE_pV4HmirnId-KWjqKCSLFIG-rcZCMd2ssiZuLWozTnpCCj6glS6ljoF7cjga9c2GdSZPNSTh10WVMubw0VAKRA');

/* Procedure structure for procedure `spCreateUser` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCreateUser` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCreateUser`(
	in inUserName varchar(128),
	in inPassword varchar(128),
	in inGameNick varchar(128),
	out result int
)
BEGIN
	-- invalid user name
	if inUserName is null or "" then
	begin
		set result = -2;
	end;
	else begin
		-- duplicated player
		declare exit handler for sqlstate '23000'
		begin 
			set result = -1;
		end;
		-- Update table
		set result = 0;
		INSERT INTO tblUser 
			(`UserName`, `UserPassword`, `GameNick`)
			VALUES
			(
			inUserName, inPassword, inGameNick
			);
	end;
	end if;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spFacebookCreateUser` */

/*!50003 DROP PROCEDURE IF EXISTS  `spFacebookCreateUser` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spFacebookCreateUser`(
	in inFBUserID bigint,
	in inGameNick varchar(60),
	in inEMail varchar(128),
	out outUID bigint,
	out result int
)
BEGIN
	declare continue handler for sqlstate '23000'
	begin 
		set result = -1;
	end;
	-- check fbname first which is not check by insert into
	if exists ( select 1 from tblUser where FBUserID = inFBUserID limit 1 )
	then begin
		set result = -2;
	end;
	else
	-- elseif
	begin
		declare exit handler for sqlstate '23000'
		begin 
			set result = -1;
		end;
		-- Update table
		set result = 0;
		INSERT INTO tblUser 
			(`FBUserID`, `GameNick`, `EMail`)
			VALUES
			(
			inFBUserID, inGameNick, inEMail
			);
		select UserUID into outUID from tblUser where FBUserID = inFBUserID;
		
	end;
	end if;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spFacebookLogin` */

/*!50003 DROP PROCEDURE IF EXISTS  `spFacebookLogin` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spFacebookLogin`(
	in inFBUserID bigint,
	out outUID bigint,
	out outGameNick varchar(60),
	out outGCMKeys varchar(512),
	out result int
)
BEGIN
	select UserUID , GameNick, GCMKeys into outUID, outGameNick, outGCMKeys from tblUser where FBUserID = inFBUserID;
	if outUID is null or outUID = 0 THEN
		-- User not found
		set result = -1;
	else begin
		update tblUser set LatestLoggedIn = NOW() where UserUID = outUID;
		set result = 0;
	end;
	end if;
	
END */$$
DELIMITER ;

/* Procedure structure for procedure `spFindPlayerByEMail` */

/*!50003 DROP PROCEDURE IF EXISTS  `spFindPlayerByEMail` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spFindPlayerByEMail`(
	in inEMail varchar(128),
	out outUID bigint,
	out outGameNick varchar(60),
	out outFBUserID bigint,
	out outResult int
)
BEGIN
	select UserUID , GameNick, FBUserID into outUID, outGameNick, outFBUserID from tblUser where EMail = inEMail limit 1;
	if outUID is null or outUID = 0 THEN
		-- User not found
		set outResult = -1;
	else begin
		set outResult = 0;
	end;
	end if;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spFriend_Add` */

/*!50003 DROP PROCEDURE IF EXISTS  `spFriend_Add` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spFriend_Add`(
	inUserID bigint,
	inFriendID bigint,
	inFacebookUID bigint,
	out result int
)
BEGIN
	declare continue handler for sqlstate '23000'
	begin 
		-- Already in the friend list
		set result = -1;
	end;
	set result = 0;
	insert into tblFriend 
		( UserUID, FriendUID, FriendFacebookUID )
		Values
		( inUserID, inFriendID, inFacebookUID );
END */$$
DELIMITER ;

/* Procedure structure for procedure `spFriend_List` */

/*!50003 DROP PROCEDURE IF EXISTS  `spFriend_List` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spFriend_List`(
	inUserUID bigint
)
BEGIN
	select FriendUID, FriendFacebookUID from tblFriend where UserUID = inUserUID;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spFriend_Remove` */

/*!50003 DROP PROCEDURE IF EXISTS  `spFriend_Remove` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spFriend_Remove`(
	inUserID bigint,
	inFriendID bigint,
	out result int
)
BEGIN

	-- not found handler
	declare continue handler for sqlstate 'HY000'
	begin 
		set result = -1;
	end;

	set result = 0;

	delete from tblFriend where UserUID = inUserID and FriendUID = inFriendID;

END */$$
DELIMITER ;

/* Procedure structure for procedure `spGetNickNames` */

/*!50003 DROP PROCEDURE IF EXISTS  `spGetNickNames` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spGetNickNames`(
	in inUserID0 bigint,
	in inUserID1 bigint,
	in inUserID2 bigint,
	in inUserID3 bigint,
	in inUserID4 bigint,
	in inUserID5 bigint,
	out outResult int
)
BEGIN

	-- not found handler
	declare continue handler for sqlstate 'HY000'
	begin
		set outResult = -1;
	end;

	set outResult = 0;

	select UserUID, GameNick from tblUser where UserUID in ( inUserID0, inUserID1, inUserID2, inUserID3, inUserID4, inUserID5 );

END */$$
DELIMITER ;

/* Procedure structure for procedure `spLogin` */

/*!50003 DROP PROCEDURE IF EXISTS  `spLogin` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spLogin`(
	in inUserName varchar(128),
	in inPassword char(128),
	out outUID bigint,
	out outFacebookUID bigint,
	out outGameNick varchar(128),
	out result int
)
BEGIN
	declare pwd char(128);
	select UserUID, FBUserID, UserPassword, GameNick into outUID, outFacebookUID, pwd, outGameNick from tblUser where UserName COLLATE utf8_general_ci = inUserName COLLATE utf8_general_ci;
	-- select UserUID , Password, GameNick from tblUser where UserName = inUserName;
	-- select outUID = UserUID , pwd = Password, outGameNick = GameNick from tblUser where UserName = inUserName;
	if pwd is null THEN
		-- User not found
		set result = -1;
	elseif pwd != inPassword then
		-- Invalid password
		set result = -2;
	else begin
		update tblUser set LatestLoggedIn = NOW() where UserUID = outUID;
		set result = 0;
	end;
	end if;
	
END */$$
DELIMITER ;

/* Procedure structure for procedure `spNotification_Add` */

/*!50003 DROP PROCEDURE IF EXISTS  `spNotification_Add` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spNotification_Add`(
	inUserID bigint,
	inIsCollapsable bool,
	inMessageID smallint,
	inMessageParam0 bigint,
	inMessageParam1 bigint,
	inMessageText varchar(512),
	out outNotificationID int,
	out result int
)
BEGIN

	if inIsCollapsable and exists ( select 1 from tblNotification where UserUID = inUserID and MessageID = inMessageID and MessageParam0 = inMessageParam0 and MessageParam1 = inMessageParam1 limit 1 )
	then begin
		-- Duplicated message
		set result = -1;

		select NotificationID into outNotificationID from tblNotification where UserUID = inUserID and MessageID = inMessageID and MessageParam0 = inMessageParam0 and MessageParam1 = inMessageParam1 limit 1;

		-- refresh Issued Time
		update tblNotification set IssuedTime = Now() where NotificationID = outNotificationID;

	end;
	else
	-- elseif
	begin
		set result = 0;

		insert into tblNotification
			( UserUID, MessageID, MessageParam0, MessageParam1, MessageText )
			Values
			( inUserID, inMessageID, inMessageParam0, inMessageParam1, inMessageText );

		set outNotificationID = LAST_INSERT_ID();

	end;
	end if;

END */$$
DELIMITER ;

/* Procedure structure for procedure `spNotification_GetList` */

/*!50003 DROP PROCEDURE IF EXISTS  `spNotification_GetList` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spNotification_GetList`(
	inUserID bigint,
	out result int
)
BEGIN
	set result = 0;
	select NotificationID, MessageID, MessageParam0, MessageParam1, MessageText from tblNotification where UserUID = inUserID order by NotificationID DESC limit 20;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spNotification_Remove` */

/*!50003 DROP PROCEDURE IF EXISTS  `spNotification_Remove` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spNotification_Remove`(
	inUserID bigint,
	inNotificationID int,
	out outResult int
)
BEGIN

	-- Not found handler
	declare continue handler for sqlstate 'HY000'
	begin
		set outResult = -1;
	end;

	set outResult = 0;

	delete from tblNotification where NotificationID = inNotificationID and UserUID = inUserID;


END */$$
DELIMITER ;

/* Procedure structure for procedure `spNotification_RemoveByMessageID` */

/*!50003 DROP PROCEDURE IF EXISTS  `spNotification_RemoveByMessageID` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spNotification_RemoveByMessageID`(
	inUserID bigint,
	inMessageID smallint,
	out outResult int
)
BEGIN
	-- Not found handler
	declare continue handler for sqlstate 'HY000'
	begin
		set outResult = -1;
	end;
	set outResult = 0;
	delete from tblNotification where UserUID = inUserID and MessageID = inMessageID;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spSetNickName` */

/*!50003 DROP PROCEDURE IF EXISTS  `spSetNickName` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spSetNickName`(
	in inUserID bigint,
	in inNickName varchar(128),
	out outResult int
)
BEGIN
	-- not found handler
	declare continue handler for sqlstate 'HY000'
	begin
		set outResult = -1;
	end;
	set outResult = 0;
	update tblUser set GameNick = inNickName where UserUID = inUserID;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spUpdateGCMKeys` */

/*!50003 DROP PROCEDURE IF EXISTS  `spUpdateGCMKeys` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spUpdateGCMKeys`(
	in inUID bigint,
	in inGCMKeys varchar(512),
	out result int
)
BEGIN
	-- not found handler
	declare exit handler for sqlstate 'HY000'
	begin 
		set result = -1;
	end;

	set result = 0;

	update tblUser set GCMKeys = inGCMKeys where UserUID = inUID;

END */$$
DELIMITER ;

/* Procedure structure for procedure `spUserList` */

/*!50003 DROP PROCEDURE IF EXISTS  `spUserList` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spUserList`(out result int)
BEGIN
	select UserUID, UserName, FBUserID, gameNick from tblUser;
	set result = ROW_COUNT();
END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
