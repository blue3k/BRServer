/*
SQLyog Job Agent v11.42 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.15 : Database - dbconspiracy00
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`dbconspiracy00` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;

USE `dbconspiracy00`;

/*Table structure for table `tblplayer` */

DROP TABLE IF EXISTS `tblplayer`;

CREATE TABLE `tblplayer` (
  `PlayerID` bigint(20) NOT NULL,
  `Grade` tinyint(4) NOT NULL DEFAULT '0',
  `Level` smallint(6) NOT NULL DEFAULT '1',
  `Exp` bigint(20) NOT NULL DEFAULT '0',
  `Money` bigint(20) NOT NULL DEFAULT '0',
  `gem` bigint(20) NOT NULL DEFAULT '0',
  `Stamina` smallint(6) NOT NULL DEFAULT '0',
  `TotalPlayed` int(11) NOT NULL DEFAULT '0',
  `WinPlaySC` int(11) NOT NULL DEFAULT '0',
  `WinPlaySM` int(11) NOT NULL DEFAULT '0',
  `LosePlaySC` int(11) NOT NULL DEFAULT '0',
  `LosePlaySM` int(11) NOT NULL DEFAULT '0',
  `WinPlayNC` int(11) NOT NULL DEFAULT '0',
  `WinPlayNM` int(11) NOT NULL DEFAULT '0',
  `LosePlayNC` int(11) NOT NULL DEFAULT '0',
  `LosePlayNM` int(11) NOT NULL DEFAULT '0',
  `Updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `FriendSlot` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`PlayerID`),
  UNIQUE KEY `PlayerID_UNIQUE` (`PlayerID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tblplayer` */

insert  into `tblplayer` values (21104,0,2,4,0,0,0,0,0,0,0,0,0,0,0,0,'2014-01-07 21:12:27',0),(21106,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,'2014-01-07 21:12:04',0),(22224,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,'2014-01-26 17:44:41',0),(22226,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,'2014-01-26 18:04:01',0),(22228,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,'2014-02-22 12:48:11',0),(22230,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,'2014-02-02 15:35:27',0);

/* Procedure structure for procedure `spGetPlayerInfo` */

/*!50003 DROP PROCEDURE IF EXISTS  `spGetPlayerInfo` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spGetPlayerInfo`(
	in inPlayerID bigint,
	out outResult int
)
BEGIN
	set outResult = 0;
	select Grade, Level, Exp, Money, Gem, Stamina, FriendSlot, TotalPlayed, WinPlaySC, WinPlaySM, LosePlaySC, LosePlaySM, WinPlayNC, WinPlayNM, LosePlayNC, LosePlayNM
		from tblplayer where PlayerID = inPlayerID;
	if FOUND_ROWS() = 0 then
	begin
		-- Create player information if not exist yet
		insert into tblPlayer (PlayerID) values ( inPlayerID );
		set outResult = 1;
		select Grade, Level, Exp, Money, Gem, Stamina, FriendSlot, TotalPlayed, WinPlaySC, WinPlaySM, LosePlaySC, LosePlaySM, WinPlayNC, WinPlayNM, LosePlayNC, LosePlayNM
			from tblplayer where PlayerID = inPlayerID;
	end;
	end if;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spSetPlayerInfo` */

/*!50003 DROP PROCEDURE IF EXISTS  `spSetPlayerInfo` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spSetPlayerInfo`(
	in inPlayerID bigint,
	in inGrade tinyint,
	in inLevel smallint,
	in inExp bigint,
	in inMoney bigint,
	in inGem bigint,
	in inStamina smallint,
	in inFriendSlot smallint,
	in inTotalPlayed int,
	in inWinPlaySC int,
	in inWinPlaySM int,
	in inLosePlaySC int,
	in inLosePlaySM int,
	in inWinPlayNC int,
	in inWinPlayNM int,
	in inLosePlayNC int,
	in inLosePlayNM int,
	out outResult int
)
BEGIN
	set outResult = 0;
	UPDATE tblplayer
		SET
		`PlayerID` = inPlayerID,
		`Grade` = inGrade,
		`Level` = inLevel,
		`Exp` = inExp,
		`Money` = inMoney,
		`gem` = inGem,
		`Stamina` = inStamina,
		`FriendSlot` = inFriendSlot, 
		`TotalPlayed` = inTotalPlayed,
		`WinPlaySC` = inWinPlaySC,
		`WinPlaySM` = inWinPlaySM,
		`LosePlaySC` = inLosePlaySC,
		`LosePlaySM` = inLosePlaySM,
		`WinPlayNC` = inWinPlayNC,
		`WinPlayNM` = inWinPlayNM,
		`LosePlayNC` = inLosePlayNC,
		`LosePlayNM` = inLosePlayNM,
		`Updated` = CURRENT_TIMESTAMP()
		WHERE PlayerID = inPlayerID;
	-- SELECT ROW_COUNT() into count ;
	IF ROW_COUNT()  = 0 THEN
	begin
		-- Create player information if not exist
		-- This case isn't be supposed to be happened, all the player inseartion must be happened in spGetPlayerInfo which is called on login process.
		-- If this happened you need to fix DB integraty. My guess is DB sharding is wrong.
		-- However, I'm going to save the data here so that we can restore the player data
		insert into tblPlayer (PlayerID, Grade, Level, Exp, Money, Gem, Stamina, FriendSlot, TotalPlayed, WinPlaySC, WinPlaySM, LosePlaySC, LosePlaySM, WinPlayNC, WinPlayNM, LosePlayNC, LosePlayNM)
				values ( inPlayerID, inGrade, inLevel, inExp, inMoney, inGem, inStamina, inFriendSlot, inTotalPlayed, inWinPlaySC, inWinPlaySM, inLosePlaySC, inLosePlaySM, inWinPlayNC, inWinPlayNM, inLosePlayNC, inLosePlayNM );
		set outResult = 1;
	end;
	end if;
END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
